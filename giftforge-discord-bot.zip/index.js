require("dotenv").config();

const {
  Client,
  GatewayIntentBits,
  REST,
  Routes,
  SlashCommandBuilder,
  AttachmentBuilder
} = require("discord.js");

const TOKEN = process.env.DISCORD_TOKEN;
const CLIENT_ID = process.env.CLIENT_ID;
const GUILD_ID = process.env.GUILD_ID;

if (!TOKEN || !CLIENT_ID || !GUILD_ID) {
  console.error("Configure DISCORD_TOKEN, CLIENT_ID et GUILD_ID dans .env");
  process.exit(1);
}

const client = new Client({ intents: [GatewayIntentBits.Guilds] });

const commands = [
  new SlashCommandBuilder()
    .setName("generate")
    .setDescription("Génère des liens fictifs de test.")
    .addIntegerOption(o =>
      o.setName("nombre").setDescription("Nombre de liens (1-5000)")
        .setRequired(false).setMinValue(1).setMaxValue(5000))
    .addIntegerOption(o =>
      o.setName("longueur").setDescription("Longueur du code (4-64)")
        .setRequired(false).setMinValue(4).setMaxValue(64)),

  new SlashCommandBuilder()
    .setName("test")
    .setDescription("Teste le format et les doublons de la dernière génération."),

  new SlashCommandBuilder()
    .setName("export")
    .setDescription("Exporte la dernière génération en fichier TXT."),

  new SlashCommandBuilder()
    .setName("stats")
    .setDescription("Affiche les statistiques de la dernière génération."),

  new SlashCommandBuilder()
    .setName("clear")
    .setDescription("Efface la dernière génération.")
].map(c => c.toJSON());

const rest = new REST({ version: "10" }).setToken(TOKEN);

async function registerCommands() {
  await rest.put(
    Routes.applicationGuildCommands(CLIENT_ID, GUILD_ID),
    { body: commands }
  );
  console.log("Commandes slash enregistrées.");
}

const sessions = new Map();
const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

function randomCode(length) {
  const values = new Uint32Array(length);
  crypto.getRandomValues(values);
  let result = "";
  for (let i = 0; i < length; i++) {
    result += alphabet[values[i] % alphabet.length];
  }
  return result;
}

function generate(count, length) {
  const set = new Set();
  const links = [];

  while (links.length < count) {
    const code = randomCode(length);
    if (!set.has(code)) {
      set.add(code);
      // Domaine volontairement non fonctionnel : aucun cadeau Discord réel.
      links.push(`https://discord.gift.invalid/${code}`);
    }
  }
  return links;
}

function getSession(userId) {
  return sessions.get(userId) || [];
}

client.once("ready", () => {
  console.log(`Connecté en tant que ${client.user.tag}`);
});

client.on("interactionCreate", async interaction => {
  if (!interaction.isChatInputCommand()) return;

  const userId = interaction.user.id;

  if (interaction.commandName === "generate") {
    const count = interaction.options.getInteger("nombre") ?? 100;
    const length = interaction.options.getInteger("longueur") ?? 16;
    const links = generate(count, length);
    sessions.set(userId, links);

    const preview = links.slice(0, 10).join("\n");
    const more = links.length > 10 ? `\n… et ${links.length - 10} autres.` : "";

    await interaction.reply({
      content:
        `### ✨ Génération terminée\n` +
        `**${links.length}** liens fictifs créés avec des codes de **${length} caractères**.\n\n` +
        "```text\n" + preview + more + "\n```\n" +
        "Utilise `/test` pour vérifier le format ou `/export` pour récupérer toute la liste."
    });
  }

  if (interaction.commandName === "test") {
    const links = getSession(userId);
    if (!links.length) {
      return interaction.reply("Aucune génération trouvée. Utilise `/generate` d'abord.");
    }

    const codes = links.map(x => x.split("/").pop());
    const unique = new Set(codes);
    const valid = codes.filter(c => /^[A-Za-z0-9]+$/.test(c)).length;
    const duplicates = codes.length - unique.size;

    const ok = valid === links.length && duplicates === 0;

    await interaction.reply(
      `${ok ? "✅" : "❌"} **Auto-test terminé**\n` +
      `Format valide : **${valid}/${links.length}**\n` +
      `Codes uniques : **${unique.size}/${links.length}**\n` +
      `Doublons : **${duplicates}**\n\n` +
      `Aucune requête vers Discord n'est effectuée.`
    );
  }

  if (interaction.commandName === "stats") {
    const links = getSession(userId);
    if (!links.length) {
      return interaction.reply("Aucune génération trouvée.");
    }

    const codes = links.map(x => x.split("/").pop());
    await interaction.reply(
      `### 📊 Statistiques\n` +
      `Liens : **${links.length}**\n` +
      `Codes uniques : **${new Set(codes).size}**\n` +
      `Longueur : **${codes[0].length}**`
    );
  }

  if (interaction.commandName === "export") {
    const links = getSession(userId);
    if (!links.length) {
      return interaction.reply("Aucune génération trouvée.");
    }

    const buffer = Buffer.from(links.join("\n") + "\n", "utf8");
    const file = new AttachmentBuilder(buffer, { name: "giftforge-liens.txt" });

    await interaction.reply({
      content: "📄 Voici ton export.",
      files: [file]
    });
  }

  if (interaction.commandName === "clear") {
    sessions.delete(userId);
    await interaction.reply("🗑️ Ta dernière génération a été effacée.");
  }
});

(async () => {
  await registerCommands();
  await client.login(TOKEN);
})();
