# GiftForge Discord Bot

Bot Discord Node.js avec :
- `/generate`
- `/test`
- `/stats`
- `/export`
- `/clear`

Les liens générés utilisent volontairement `discord.gift.invalid` :
ils sont fictifs et le bot ne contacte pas Discord pour vérifier des cadeaux.

## Installation

1. Installe Node.js 18 ou plus récent.
2. Ouvre un terminal dans ce dossier.
3. Lance :

```bash
npm install
```

4. Copie `.env.example` vers `.env`.
5. Remplis `DISCORD_TOKEN`, `CLIENT_ID` et `GUILD_ID`.
6. Lance :

```bash
npm start
```

## Configuration du bot

Crée une application/bot dans le portail développeur Discord, récupère son token et son Application ID.
Pour tester les commandes rapidement, renseigne aussi l'ID du serveur de test (`GUILD_ID`).

Ne partage jamais ton token Discord et ne le mets pas dans GitHub.
